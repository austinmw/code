This directory will contain list information that will be helpful in attacking both SOAP and REST-based web services.
