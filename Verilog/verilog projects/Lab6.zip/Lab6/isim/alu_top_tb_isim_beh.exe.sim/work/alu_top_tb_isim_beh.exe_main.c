/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

#include "xsi.h"

struct XSI_INFO xsi_info;



int main(int argc, char **argv)
{
    xsi_init_design(argc, argv);
    xsi_register_info(&xsi_info);

    xsi_register_min_prec_unit(-12);
    work_m_17566024640923838779_0612177658_init();
    work_m_17607930559397885458_1514806922_init();
    work_m_10562666065387352993_2931155317_init();
    work_m_01396436623024350635_0886308060_init();
    work_m_02899448284234580645_3488697238_init();
    work_m_14415810171100974088_3566469229_init();
    work_m_00731771854612348473_3449573697_init();
    work_m_16541823861846354283_2073120511_init();


    xsi_register_tops("work_m_00731771854612348473_3449573697");
    xsi_register_tops("work_m_16541823861846354283_2073120511");


    return xsi_run_simulation(argc, argv);

}
